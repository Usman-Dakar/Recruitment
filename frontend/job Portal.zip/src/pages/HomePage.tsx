import { useState, useRef, useTransition } from 'react'
import { useNavigate } from 'react-router-dom'
import { Search, Filter, X } from 'lucide-react'
import { jobCategories } from '@/data/jobCategories'
import SearchResults from '@/components/search/SearchResults'
import FilterDrawer from '@/components/common/FilterDrawer'
import { useSearchStore, defaultSearchParams } from '@/store/searchStore'
import { useJobSearch } from '@/hooks/useJobSearch'

const categoryIcons: Record<number, string> = {
  11: '🏢', 12: '💼', 13: '🏨', 14: '🏥',
  15: '⚙️', 16: '🏗️', 17: '💻', 21: '🏠',
  22: '⚡', 27: '🍽️', 28: '🔒', 29: '✨',
}

export default function HomePage() {
  const navigate = useNavigate()
  const { params, setParams, resetParams } = useSearchStore()
  const { search } = useJobSearch()
  const [globalSearch, setGlobalSearch] = useState('')
  const [filterOpen, setFilterOpen] = useState(false)
  const [isPending, startTransition] = useTransition()
  const resultsRef = useRef<HTMLDivElement>(null)

  const triggerGlobalSearch = () => {
    const searchParams = { ...defaultSearchParams, freeText: globalSearch, pageNo: 1 }
    setParams(searchParams)
    startTransition(async () => {
      await search(searchParams)
      resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' })
    })
  }

  const handleCategoryClick = (categoryId: number) => {
    navigate(`/jobs/${categoryId}`)
  }

  return (
    <div className="min-h-[calc(100svh-4rem)]">

      {/* ── Hero ── */}
      <section className="relative hero-grid overflow-hidden pt-20 pb-28 px-4 sm:px-6 flex flex-col items-center justify-center min-h-[72vh]">
        {/* Ambient glow */}
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] rounded-full pointer-events-none"
          style={{ background: 'radial-gradient(ellipse, rgba(124,58,237,0.12) 0%, transparent 70%)' }}
          aria-hidden="true"
        />

        <div className="relative z-10 max-w-3xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-brand-500/10 border border-brand-500/20 rounded-full text-xs font-medium text-brand-400 mb-6 animate-fade-in-up">
            <span className="w-1.5 h-1.5 rounded-full bg-brand-400 animate-pulse" aria-hidden="true" />
            Malta's Premier Job Portal
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-[1.1] tracking-tight mb-5 animate-fade-in-up delay-100">
            <span className="text-slate-100">Discover Your Next</span>
            <br />
            <span className="gradient-text">Career Opportunity</span>
          </h1>

          <p className="text-base sm:text-lg text-slate-400 mb-10 max-w-xl mx-auto leading-relaxed animate-fade-in-up delay-200">
            AX Group offers countless opportunities across hospitality, real estate, technology, and more — all in Malta.
          </p>

          {/* Global search bar */}
          <div className="flex gap-2 max-w-xl mx-auto animate-fade-in-up delay-300">
            <div className="relative flex-1 min-w-0">
              <Search
                className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none"
                aria-hidden="true"
              />
              <input
                type="search"
                id="globalSearchTb"
                value={globalSearch}
                onChange={(e) => setGlobalSearch(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && triggerGlobalSearch()}
                placeholder="Search by Job Title or Skill"
                autoComplete="off"
                className="w-full pl-10 pr-4 py-3.5 bg-surface-700/80 border border-white/10 rounded-xl text-sm text-slate-200 placeholder:text-slate-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand-500"
              />
            </div>
            <button
              type="button"
              onClick={triggerGlobalSearch}
              disabled={isPending}
              className="px-6 py-3.5 bg-brand-500 text-white rounded-xl font-semibold text-sm hover:bg-brand-400 disabled:opacity-60 transition-colors whitespace-nowrap shrink-0"
            >
              {isPending ? 'Searching…' : 'Find Openings'}
            </button>
          </div>

          <p className="mt-4 text-xs text-slate-500 animate-fade-in-up delay-400">
            25+ open positions across all sectors
          </p>
        </div>
      </section>

      {/* ── Category quick-filters ── */}
      <section className="py-14 px-4 sm:px-6 bg-surface-900/50 border-y border-white/5" aria-label="Browse by category">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-xl font-bold text-slate-100 mb-1">Browse by Category</h2>
            <p className="text-sm text-slate-400">Jump straight to your sector</p>
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-12 gap-2 sm:gap-3">
            {jobCategories.map((cat) => (
              <button
                key={cat.value}
                type="button"
                onClick={() => handleCategoryClick(cat.value)}
                className="glass rounded-xl p-3 text-center hover:border-brand-500/40 hover:bg-brand-500/5 transition-all duration-200 group flex flex-col items-center gap-2"
              >
                <span className="text-2xl leading-none" role="img" aria-hidden="true">
                  {categoryIcons[cat.value] ?? '📌'}
                </span>
                <span className="text-[11px] font-medium text-slate-400 group-hover:text-slate-200 transition-colors leading-tight">
                  {cat.label}
                </span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ── Job results + filter ── */}
      <section className="py-12 px-4 sm:px-6" ref={resultsRef} aria-label="Job listings">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-slate-100">Open Positions</h2>
            <div className="flex items-center gap-2">
              {params.freeText && (
                <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-brand-500/10 border border-brand-500/20 text-brand-400 text-xs rounded-full">
                  <span className="min-w-0 truncate max-w-[120px]">&ldquo;{params.freeText}&rdquo;</span>
                  <button
                    type="button"
                    aria-label="Clear keyword filter"
                    onClick={() => {
                      const reset = { ...params, freeText: '', pageNo: 1 }
                      setParams(reset)
                      search(reset)
                    }}
                    className="text-brand-400 hover:text-white transition-colors"
                  >
                    <X className="w-3 h-3" aria-hidden="true" />
                  </button>
                </span>
              )}
              <button
                type="button"
                id="openSidebar"
                onClick={() => setFilterOpen(true)}
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium glass rounded-lg hover:border-brand-500/30 transition-colors"
              >
                <Filter className="w-3.5 h-3.5" aria-hidden="true" />
                Filter
              </button>
            </div>
          </div>

          <SearchResults />
        </div>
      </section>

      <FilterDrawer
        isOpen={filterOpen}
        onClose={() => setFilterOpen(false)}
        onReset={resetParams}
      />
    </div>
  )
}
